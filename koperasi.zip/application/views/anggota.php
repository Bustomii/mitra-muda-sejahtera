<script type="text/javascript">
$(function() {
	$("#theTable tr:even").addClass("stripe1");
	$("#theTable tr:odd").addClass("stripe2");
	$("#theTable tr").hover(
		function() {
			$(this).toggleClass("highlight");
		},
		function() {
			$(this).toggleClass("highlight");
		}
	);
});
$(document).ready(function(){	
	$(':input:not([type="submit"])').each(function() {
		$(this).focus(function() {
			$(this).addClass('hilite');
		}).blur(function() {
			$(this).removeClass('hilite');});
	});
	
	$("#anggota").keyup(function(e){
		var isi = $(e.target).val();
		$(e.target).val(isi.toUpperCase());
		CariAnggota(isi);
	});
	
	$("#tgl_lhr").datepicker({
			dateFormat:"dd-mm-yy",
			changeYear : true,
			changeMonth:true,
			yearRange : "-100:+0",
			modal : true
    });
	
	function tampil_data(){
		
		$('#form_input').hide();
		$('#tombol_input').hide();
		$('.tampil_data').show();
		$('#tombol').show();
		$('#pencarian').show();
		$('#paging').show();
	}
	function input_data(){
		$('#form_input').show();
		$('#tombol_input').show();
		$('.tampil_data').hide();
		$('#tombol').hide();
		$('#pencarian').hide();
		$('#paging').hide();
	}
	
	tampil_data();
	
	$("#tambah").click(function(){
		input_data();
		$('input').val('');
		$('select').val('');
		CariKode();
		$('#identitas').focus();
	});
	
	$("#kosong").click(function(){
		$('input').val('');
		$('select').val('');
		CariKode();
		$('#identitas').focus();
	});
	
	$("#tutup").click(function(){
		//tampil_data();
		window.location.replace('<?php echo site_url();?>/anggota/index');
	});
	
	function CariKode(){
		$.ajax({
			type	: "POST",
			url		: "<?php echo site_url(); ?>/anggota/CariKode",
			dataType: "json",
			success	: function(data){
				$('#nomor').val(data.nomor);
			}
		});
	}
	$("#refresh").click(function(){
		window.location.replace('<?php echo site_url();?>/anggota/index');
	});
	
	$("#simpan").click(function(){
		simpan();
	});
	
	function simpan(){
		var nomor		= $("#nomor").val();
		var identitas	= $("#identitas").val();
		var anggota		= $("#anggota").val();
		var jk			= $("#jk").val();
		var tempat_lhr	= $("#tempat_lhr").val();
		var tgl_lhr		= $("#tgl_lhr").val();
		var hp			= $("#hp").val();
		var alamat		= $("#alamat").val();
		
		var string = "nomor="+nomor+"&identitas="+identitas+"&anggota="+anggota+
					"&jk="+jk+"&tempat_lhr="+tempat_lhr+"&tgl_lhr="+tgl_lhr+
					"&hp="+hp+"&alamat="+alamat;
		//alert('Info '+string);
		
		if(identitas.length==0){
			alert('Maaf, Nomor Identitas tidak boleh kosong');
			$("#identitas").focus();
			return false();
		}
		if(anggota.length==0){
			alert('Maaf, Nama Anggota tidak boleh kosong');
			$("#anggota").focus();
			return false();
		}
		if(tgl_lhr.length==0){
			alert('Maaf, Tanggal Lahie tidak boleh kosong');
			$("#tgl_lhr").focus();
			return false();
		}
		$.ajax({
			type	: 'POST',
			url		: "<?php echo site_url(); ?>/anggota/simpan",
			data	: string,
			cache	: false,
			success	: function(data){
				//alert('Info '+data);
				//window.parent.location.reload(true);
				$.messager.show({
					title:'Info',
					msg:data, //'Password Tidak Boleh Kosong.',
					timeout:2000,
					showType:'slide'
				});
			},
			error : function(xhr, teksStatus, kesalahan) {
				$.messager.show({
					title:'Info',
					msg: 'Server tidak merespon :'+kesalahan,
					timeout:2000,
					showType:'slide'
				});
			}
		});		
	}
});

function tampil_data(){
	$('#form_input').hide();
	$('#tombol_input').hide();
	$('.tampil_data').show();
	$('#tombol').show();
	$('#pencarian').show();
	$('#paging').show();
}
function input_data(){
	$('#form_input').show();
	$('#tombol_input').show();
	$('.tampil_data').hide();
	$('#tombol').hide();
	$('#pencarian').hide();
	$('#paging').hide();
}
	
function editData(ID){
	var cari	= ID;	
	$.ajax({
		type	: "POST",
		url		: "<?php echo site_url(); ?>/anggota/cari",
		data	: "cari="+cari,
		dataType: "json",
		success	: function(data){
			input_data();
			
			$('#nomor').val(ID);
			$('#identitas').val(data.identitas);
			$('#anggota').val(data.anggota);		
			$('#jk').val(data.jk);		
			$('#tempat_lhr').val(data.tempat_lhr);
			$('#tgl_lhr').val(data.tgl_lhr);
			$('#hp').val(data.hp);						
			$('#alamat').val(data.alamat);		
			
			$('#identitas').focus();	
		}
	});
	
}

function deleteData(ID) {
	var id	= ID;
   var pilih = confirm('Data yang akan dihapus  = '+id+ '?');
	if (pilih==true) {
		$.ajax({
			type	: "POST",
			url		: "<?php echo site_url(); ?>/anggota/hapus",
			data	: "id="+id,
			success	: function(data){
				window.parent.location.reload(true);
			}
		});
	}
}
</script>
<style type="text/css">
#tombol {
	float:left;
}
#pencarian {
	float:right;
}
</style>
<div class="atas">
	<p><img src="<?php echo base_url();?>/asset/css/themes/icons/users.png" align="absmiddle" />
	DAFTAR ANGGOTA
    </p>
</div>
<div class="tengah">
	<div id="tombol_proses">
        <div id="tombol">
        <?php echo form_button($tambah,'Tambah Data'); ?>
        <?php echo form_button($refresh,'Refresh Data'); ?>
        </div>
        <div id="pencarian">
        <?php echo form_open('anggota/index'); ?>
        Pencarian <?php echo form_input($cari); ?>
        <?php echo form_close(); ?>
        </div>
	</div>
	<div class="tampil_data">
    <table id="theTable" width="100%">
    <tr>
    	<th width="5">No</th>
        <th width="50">Nomor</th>
        <th>No.Identitas</th>
        <th>Nama Anggota</th>
        <th>Jenis Kelamin</th>
        <th>HP</th>
        <th width="50">Aksi</th>
	</tr>   
    <?php
	if($dt_anggota->num_rows()>0){
		$no =1+$hal;
		foreach($dt_anggota->result_array() as $db){
		if($db['jk']=='L'){
			$sex = 'Laki-laki';
		}else{
			$sex = 'Perempuan';
		}
	?>    
    	<tr>
			<td align="center"><?php echo $no; ?></td>
            <td align="center"><?php echo $db['noanggota']; ?></td>
            <td align="center"><?php echo $db['noidentitas']; ?></td>
			<td><?php echo $db['namaanggota']; ?></td>
            <td align="center"><?php echo $sex; ?></td>
            <td align="left"><?php echo $db['hp']; ?></td>
            <td align="center">
            <a href="javascript:editData('<?php echo $db['noanggota'] ?>')">
			<img src="<?php echo base_url();?>asset/images/ed.png" title='Ubah'>
			</a>
            <a href="javascript:deleteData('<?php echo $db['noanggota']; ?>')">
			<img src="<?php echo base_url();?>asset/images/del.png" title='Hapus'>
			</a>
            </td>
    </tr>
    <?php
		$no++;
		}
	}else{
	?>
    	<tr>
        	<td colspan="5" align="center" >Tidak Ada Data</td>
        </tr>
    <?php
	}
	?>
    </table>
    </div>
    <div id="form_input">
    <p><label>Nomor</label>:<?php echo form_input($nomor); ?></p>
    <p><label>No.Identitas</label>:<?php echo form_input($identitas); ?></p>
    <p><label>Nama Anggota</label>:<?php echo form_input($anggota); ?></p>
    <p><label>Jenis Kelamin</label>:<?php echo form_dropdown('jk',$opt_jk,'',$jk); ?></p>
    <p><label>Tempat Lahir</label>:<?php echo form_input($tempat_lhr); ?></p>
    <p><label>Tanggal Lahir</label>:<?php echo form_input($tgl_lhr); ?></p>
    <p><label>HP</label>:<?php echo form_input($hp); ?></p>
    <p><label>Alamat</label>:<?php echo form_input($alamat); ?></p>
    
    </div>
</div>
<div class="bawah">
	<div id="paging">
	<center><?php echo $paginator; ?></center>
    </div>
    <div id="tombol_input">
    <center><?php echo form_button($simpan,'SIMPAN'); ?>
	<?php echo form_button($kosong,'KOSONG'); ?>
    <?php echo form_button($tutup,'TUTUP'); ?></center>
    </div>
</div>