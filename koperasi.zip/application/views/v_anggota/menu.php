<ul id="tt1" class="easyui-tree" data-options="animate:true,dnd:true">
    <li data-options="iconCls:'icon-home'">
        <span><a href="<?php echo base_url(); ?>index.php/c_anggota/home">Home</a></span>
    </li>
    <li data-options="iconCls:'icon-profil'"><a href="<?php echo base_url(); ?>index.php/c_anggota/profil">Profil</a></li>
    <li data-options="iconCls:'icon-simpanan'"><a href="<?php echo base_url(); ?>index.php/c_anggota/simpanan">Simpanan</a></li>
    <li data-options="iconCls:'icon-pinjaman'"><a href="<?php echo base_url(); ?>index.php/c_anggota/pinjaman">Pinjaman</a></li>
	<li data-options="iconCls:'icon-out'">
        <span><a href="<?php echo base_url(); ?>index.php/c_anggota/home/logout">Keluar</a></span>
    </li>
</ul>