<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Profil extends CI_Controller {

	/**
	 * @author : Deddy Rusdiansyah,S.Kom
	 * @web : http://deddyrusdiansyah.blogspot.com
	 * @keterangan : Controller untuk halaman profil
	 **/

	public function index()
	{
		$cek = $this->session->userdata('logged_in');
		$level = $this->session->userdata('level');
		if(!empty($cek) && $level=='admin'){
			$d['judul'] = $this->config->item('judul');
			$d['nama_perusahaan'] = $this->config->item('nama_perusahaan');
			$d['alamat_perusahaan'] = $this->config->item('alamat_perusahaan');
			$d['lisensi'] = $this->config->item('lisensi_app');
			$d['jam_now'] = $this->app_model->Jam_Now(); 
			$d['hari_now'] = $this->app_model->Hari_Bulan_Indo(); 
			$d['tgl_now'] = $this->app_model->tgl_now_indo();
			
			$pilih['id'] = '1'; //$this->uri->segment(3);
			$dt_profil = $this->app_model->getSelectedData("profile",$pilih);
			foreach($dt_profil->result() as $db)
			{
				$d['koperasi'] = $db->koperasi;
				$d['alamat'] = $db->alamat;
				$d['kota'] = $db->kota;
				$d['hp'] = $db->hp;
				$d['fax'] = $db->fax;
				$d['email'] = $db->email;
			}
			
			$d['koperasi'] = array('name' => 'koperasi',
				'id' => 'koperasi',
				'type' => 'text',
				'class' => 'easyui-validatebox',
				'value' => $d['koperasi'],
				'size' => '50',
				'maxlength' => '50',
				'data-options' => 'required:true,validType:\'length[1,50]\''
			);
			$d['alamat'] = array('name' => 'alamat',
				'id' => 'alamat',
				'type' => 'text',
				'class' => 'easyui-validatebox',
				'value' => $d['alamat'],
				'size' => '50',
				'maxlength' => '50',
				'data-options' => 'required:true,validType:\'length[1,50]\''
			);
			$d['kota'] = array('name' => 'kota',
				'id' => 'kota',
				'type' => 'text',
				'class' => 'easyui-validatebox',
				'value' => $d['kota'],
				'size' => '50',
				'maxlength' => '50'
			);
			$d['hp'] = array('name' => 'hp',
				'id' => 'hp',
				'type' => 'text',
				'class' => 'easyui-validatebox',
				'value' => $d['hp'],
				'size' => '20',
				'maxlength' => '50'
			);
			$d['fax'] = array('name' => 'fax',
				'id' => 'fax',
				'type' => 'text',
				'class' => 'easyui-validatebox',
				'value' => $d['fax'],
				'size' => '20',
				'maxlength' => '50'
			);
			$d['email'] = array('name' => 'email',
				'id' => 'email',
				'type' => 'text',
				'class' => 'easyui-validatebox',
				'value' => $d['email'],
				'size' => '50',
				'maxlength' => '50'
			);
			
			$d['simpan'] = array('name' => 'simpan',
				'id' => 'simpan',
				'type' => 'submit',
				'class' => 'easyui-linkbutton',
				'data-options' => 'iconCls:\'icon-save\''
			);
			
			$d['isi'] = $this->load->view('profil', $d, true);		
			$this->load->view('media',$d);
		}else{
			redirect('/koperasi/logout/','refresh');
		}
	}
	public function simpan()
	{
		$cek = $this->session->userdata('logged_in');
		$level = $this->session->userdata('level');
		if(!empty($cek) && $level=='admin'){
				$up['koperasi'] = $this->input->post('koperasi');
				$up['alamat'] = $this->input->post('alamat');
				$up['kota'] = $this->input->post('kota');
				$up['hp'] = $this->input->post('hp');
				$up['fax'] = $this->input->post('fax');
				$up['email'] = $this->input->post('email');
				$id['id'] = '1';
				$this->app_model->updateData("profile",$up,$id);
				echo "Update data sukses";	
		}else{
				redirect('/koperasi/logout/','refresh');
		}
	}
	
}

/* End of file profil.php */
/* Location: ./application/controllers/profil.php */